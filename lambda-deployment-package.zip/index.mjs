import AWS from 'aws-sdk';

const cognito = new AWS.CognitoIdentityServiceProvider();

const COGNITO_USER_POOL_ID = process.env.COGNITO_USER_POOL_ID;
const COGNITO_APP_CLIENT_ID = process.env.COGNITO_APP_CLIENT_ID;

export const handler = async (event) => {
    const { action, email, password } = event;

    try {
        if (action === 'register') {
            // Register User
            const params = {
                UserPoolId: COGNITO_USER_POOL_ID,
                Username: email,
                TemporaryPassword: password,
                UserAttributes: [
                    {
                        Name: 'email',
                        Value: email
                    },
                    {
                        Name: 'email_verified',
                        Value: 'true'
                    }
                ],
                MessageAction: 'SUPPRESS' // This suppresses sending the welcome email
            };
            await cognito.adminCreateUser(params).promise();
            
            // Set the user's password
            const adminSetPasswordParams = {
                Password: password,
                UserPoolId: COGNITO_USER_POOL_ID,
                Username: email,
                Permanent: true
            };
            await cognito.adminSetUserPassword(adminSetPasswordParams).promise();

            return { message: 'User registered successfully' };
        } else if (action === 'login') {
            // Authenticate User
            const params = {
                AuthFlow: "USER_PASSWORD_AUTH",
                ClientId: process.env.COGNITO_APP_CLIENT_ID, // Make sure this is correct
                AuthParameters: {
                    USERNAME: email, // Replace with actual email variable
                    PASSWORD: password // Replace with actual password variable
                }
            };
            
            const authResult = await cognito.initiateAuth(params).promise();
            return {
                message: 'Login successful',
                token: authResult.AuthenticationResult.IdToken
            };
        } else {
            return { message: 'Invalid action' };
        }
    } catch (error) {
        return { error: error.message };
    }
};
